1. Download the archive file from developit.ir
2. Unpack the downloaded file to a Web-accessible folder.
3. Run install.php :)
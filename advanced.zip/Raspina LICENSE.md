The Raspina CMS is free software. It is released under the terms of
the following GPL Version 3 License.

https://www.gnu.org/copyleft/gpl.html

Copyright © 2016 by Ehsan Rezaei (http://www.developit.ir)
All rights reserved.
